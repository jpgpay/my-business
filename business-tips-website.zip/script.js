const tips=[
  "Har din apne business ke 3 important tasks complete karein.",
  "Customer feedback ko note karke product/service improve karein.",
  "Monthly income aur expenses ka record zaroor rakhein.",
  "Social media par consistency rakhein—quality content share karein."
];
function showTip(){
  document.getElementById("tip").textContent =
    tips[Math.floor(Math.random()*tips.length)];
}